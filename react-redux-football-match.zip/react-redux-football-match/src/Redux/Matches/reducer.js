export const reducer = () => {
  // Complete the logic
};
