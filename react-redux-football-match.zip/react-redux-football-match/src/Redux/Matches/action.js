export const getMatches = () => {
  // Complete the logic
};
