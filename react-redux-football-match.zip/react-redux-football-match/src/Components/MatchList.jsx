import React from "react";

export const MatchList = () => {
  return <div data-testid="match-list">{/* // Show matches here  */}</div>;
};
