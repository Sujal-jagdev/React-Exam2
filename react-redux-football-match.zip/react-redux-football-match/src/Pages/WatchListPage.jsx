export const WatchListPage = () => {
  return (
    <div>
      <div data-testid="watch-list"></div>
    </div>
  );
};
