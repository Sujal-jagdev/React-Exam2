export const PrivateRoute = ({ children }) => {
  return <>{/* Complete this higher order component  */}</>;
};
