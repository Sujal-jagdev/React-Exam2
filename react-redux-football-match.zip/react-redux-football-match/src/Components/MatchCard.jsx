import React from "react";

export const MatchCard = () => {
  return (
    <div className="match-card">
      {/* show the match details   */}
      {/* use any static image, its not provided in server data  */}
    </div>
  );
};
